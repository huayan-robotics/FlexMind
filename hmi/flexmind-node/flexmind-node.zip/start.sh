#!/usr/bin/env bash
# start.sh

# 如需先 source 某些环境，或打印日志，可在此处理
echo "Starting Koa-ROSbridge-SocketIO service..."
node src/index.js
