# FlexiMind-Node

## 简介
这是一个基于 Koa 的 Node.js Web 应用示例，包含基础中间件、路由、错误处理、日志、静态文件托管、配置管理等。

## 目录结构
koa-rosbridge-socketio/
├── public/
│   └── index.html             # 前端示例页面
├── src/
│   ├── index.js               # 启动入口：创建 HTTP + Socket.IO Server，并初始化 rosBridgeService
│   ├── app.js                 # Koa 应用：挂载中间件 & HTTP 路由（可选）
│   ├── middleware/
│   │   ├── logger.js          # 简单日志中间件
│   │   └── error-handler.js    # 全局错误处理中间件
│   ├── services/
│   │   └── rosBridgeService.js# rosbridge 客户端封装：connect, subscribe, publish, callService...
│   ├── routes/
│   │   └── ros-routes.js       # (可选) HTTP 路由示例：通过 HTTP 发布/查询
│   └── utils/
│       └── responseHelper.js  # (可选) 统一 HTTP 响应格式
├── config/
│       └── default.js         # 读取 .env 配置（rosbridge URL、port 等）
├── .env.example               # 环境变量示例
├── package.json
├── start.sh                   # 启动脚本：可选，用于设置环境变量再启动 Node 应用
└── README.md

## 环境要求
- Node.js 版本 >= 18.0.0
- npm 版本 >= 9.0.0
