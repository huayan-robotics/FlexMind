// config/default.js
require('dotenv').config(); // 加载 .env
const os = require('os');

/**
 * 获取本机局域网IP地址
 * @returns {string} 本机IP地址，如果获取失败则返回 'localhost'
 */
function getLocalIP() {
  const interfaces = os.networkInterfaces();

  // 优先查找 IPv4 地址，排除回环地址和内部地址
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      // 跳过内部地址（非IPv4）和回环地址
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }

  // 如果没找到，返回 localhost
  return 'localhost';
}

// 获取动态IP
const localIP = getLocalIP();
const frontendPort = process.env.FRONTEND_PORT || '5174';
const rosbridgePort = process.env.ROSBRIDGE_PORT || '9090';

const config = {
  port: process.env.PORT || 3001,
  env: process.env.NODE_ENV || 'development',
  // 支持通过环境变量 CORS_ORIGIN 覆盖，否则使用动态IP
  corsOrigin: process.env.CORS_ORIGIN || `http://${localIP}:${frontendPort}`,
  socketioCorsOrigin: process.env.SOCKETIO_CORS_ORIGIN || '*',
  // 可通过环境变量 ROSBRIDGE_URL 覆盖，例如 ws://10.20.211.221:9090 或 wss://example.com/ros
  // 如果未设置 ROSBRIDGE_URL，则使用动态IP
  rosbridgeWsUrl: process.env.ROSBRIDGE_URL || `ws://${localIP}:${rosbridgePort}`,
  // 导出本机IP，供其他地方使用
  localIP: localIP
  // 其它配置项，如数据库连接等，可在此添加
};

module.exports = config;
