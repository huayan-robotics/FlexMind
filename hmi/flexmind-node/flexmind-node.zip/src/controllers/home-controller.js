// src/controllers/home-controller.js

exports.index = async (ctx) => {
  console.log(ctx);
  
  // 示例首页
  ctx.success({
    message: 'Welcome to Koa App!'
  });
};
