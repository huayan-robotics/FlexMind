// src/controllers/user-controller.js
const userService = require('../services/userService');

exports.getUser = async (ctx) => {
  const id = ctx.params.id;
  // 从 service 获取用户数据，若不存在则抛出错误
  const user = await userService.findById(id);
  if (!user) {
    // 抛出 404 错误
    const err = new Error('用户未找到');
    err.status = 404;
    err.code = 'USER_NOT_FOUND';
    throw err;
  }
  ctx.success(user);
};

exports.listUsers = async (ctx) => {
  // 支持分页示例：?page=1&limit=10
  const page = parseInt(ctx.query.page) || 1;
  const limit = parseInt(ctx.query.limit) || 10;
  const result = await userService.list({ page, limit });
  ctx.success(result);
};

exports.createUser = async (ctx) => {
  const { name, email } = ctx.request.body;
  if (!name || !email) {
    const err = new Error('参数 name 和 email 必填');
    err.status = 400;
    err.code = 'INVALID_PARAMS';
    throw err;
  }
  const newUser = await userService.create({ name, email });
  ctx.status = 201; // 创建成功
  ctx.success(newUser);
};
