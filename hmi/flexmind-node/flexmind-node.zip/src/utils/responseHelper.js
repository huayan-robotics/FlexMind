// src/utils/responseHelper.js

module.exports = () => {
  return async (ctx, next) => {
    // 在 ctx 上挂载方法
    ctx.success = (data) => {
      ctx.body = {
        success: true,
        data,
        error: null
      };
    };
    ctx.fail = (code, message) => {
      ctx.body = {
        success: false,
        data: null,
        error: {
          code,
          message
        }
      };
    };
    await next();
  };
};
