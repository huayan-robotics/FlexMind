// src/routes/compat.js
const Router = require('@koa/router');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const archiver = require('archiver');

const router = new Router();

// 兼容旧端点：POST /playbackService
// - 若包含文件字段(file/upload/data)且有 path -> 执行导入
// - 若仅提供 path -> 执行导出并返回 zip
router.post('/playbackService', async (ctx) => {
  try {
    const files = ctx.request.files || {};
    const body = ctx.request.body || {};

    const maybeFile = files.file || files.upload || files.data;
    const destinationPath = body.path;
    const importFiles = body.import_files;
    const targetDirectory = body.target_directory;

    if (!destinationPath || typeof destinationPath !== 'string') {
      ctx.status = 400;
      ctx.body = { success: false, error: '缺少 path 参数或类型错误' };
      return;
    }

    // 导入：有文件
    if (maybeFile) {
      const resolvedPath = path.isAbsolute(destinationPath)
        ? destinationPath
        : path.resolve(process.cwd(), destinationPath);

      const targetDir = path.dirname(resolvedPath);
      await fsp.mkdir(targetDir, { recursive: true });

      const uploaded = Array.isArray(maybeFile) ? maybeFile[0] : maybeFile;
      const tempPath = uploaded.filepath || uploaded.path;
      if (!tempPath || !fs.existsSync(tempPath)) {
        ctx.status = 400;
        ctx.body = { success: false, error: '临时上传文件不存在' };
        return;
      }

      await fsp.copyFile(tempPath, resolvedPath);
      ctx.body = { success: true, path: resolvedPath };
      return;
    }

    // JSON 批量导入：无文件，包含 import_files + target_directory
    if (importFiles || targetDirectory) {
      // 如果提供了参数但类型不正确，给出警告但不阻止执行
      if (importFiles && !Array.isArray(importFiles)) {
        console.warn('[compat playbackService] import_files 不是数组，将被忽略:', importFiles);
        importFiles = null;
      }
      if (targetDirectory && typeof targetDirectory !== 'string') {
        console.warn('[compat playbackService] target_directory 不是字符串，将被忽略:', targetDirectory);
        targetDirectory = null;
      }

      // 如果两个参数都不存在，跳过批量导入
      if (!importFiles || !targetDirectory) {
        console.log('[compat playbackService] 跳过批量导入，参数不完整');
        // 继续执行导出逻辑
      } else {
        const resolvedTarget = path.isAbsolute(targetDirectory)
          ? targetDirectory
          : path.resolve(process.cwd(), targetDirectory);
        await fsp.mkdir(resolvedTarget, { recursive: true });

      const results = [];
      const projectRoot = path.resolve(__dirname, '../../');
      const uploadsBase = process.env.UPLOADS_BASE || '';
      for (const src of importFiles) {
        if (typeof src !== 'string') {
          console.warn('[compat playbackService] 非字符串路径被忽略:', src);
          results.push({ source: src, ok: false, reason: '非字符串路径' });
          continue;
        }
        let resolvedSrc = src;
        if (!path.isAbsolute(src)) {
          const candidates = [
            path.resolve(projectRoot, src),
            path.resolve(process.cwd(), src),
            path.resolve(projectRoot, 'public', src),
            path.resolve(projectRoot, 'uploads', path.basename(src)),
          ];
          if (uploadsBase) candidates.unshift(path.resolve(uploadsBase, src));
          const existFlags = await Promise.all(candidates.map(p => fsp.access(p).then(() => true).catch(() => false)));
          console.log('[compat playbackService] 相对路径候选:', { src, candidates, existFlags, projectRoot, cwd: process.cwd(), uploadsBase });
          const idx = existFlags.findIndex(Boolean);
          if (idx >= 0) {
            resolvedSrc = candidates[idx];
          } else {
            resolvedSrc = candidates[0];
          }
        }
        const exists = await fsp.access(resolvedSrc).then(() => true).catch(() => false);
        console.log('[compat playbackService] 检查源文件:', { src, resolvedSrc, exists });
        if (!exists) {
          results.push({ source: resolvedSrc, ok: false, reason: '源文件不存在' });
          console.warn('[compat playbackService] 源文件不存在:', resolvedSrc);
          continue;
        }
        const dest = path.join(resolvedTarget, path.basename(resolvedSrc));
        try {
          await fsp.copyFile(resolvedSrc, dest);
          const copied = await fsp.access(dest).then(() => true).catch(() => false);
          console.log('[compat playbackService] 复制结果:', { from: resolvedSrc, to: dest, copied });
          results.push({ source: resolvedSrc, dest, ok: copied, reason: copied ? undefined : '目标校验失败' });
        } catch (e) {
          console.error('[compat playbackService] 复制失败:', { from: resolvedSrc, to: dest, error: e.message });
          results.push({ source: resolvedSrc, dest, ok: false, reason: e.message });
        }
      }

      const okCount = results.filter(r => r.ok).length;
      if (okCount === 0) {
        ctx.status = 404;
        ctx.body = { success: false, error: '未找到任何源文件或全部复制失败', imported: results, target: resolvedTarget };
      } else {
        ctx.body = { success: true, imported: results, target: resolvedTarget };
      }
      return;
      }
    }

    // 导出：无文件，只有 path
    const resolved = path.isAbsolute(destinationPath)
      ? destinationPath
      : path.resolve(process.cwd(), destinationPath);

    const exists = await fsp.access(resolved).then(() => true).catch(() => false);
    if (!exists) {
      ctx.status = 404;
      ctx.body = { success: false, error: '文件不存在' };
      return;
    }

    const stat = await fsp.stat(resolved);
    const baseName = path.basename(resolved);
    const zipName = baseName + '.zip';

    ctx.set('Content-Type', 'application/zip');
    ctx.set('Content-Disposition', `attachment; filename="${zipName}"`);

    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.on('error', (err) => { throw err; });
    archive.pipe(ctx.res);

    if (stat.isDirectory()) {
      archive.directory(resolved, baseName);
    } else {
      archive.file(resolved, { name: baseName });
    }

    await archive.finalize();
    ctx.respond = false;
  } catch (err) {
    ctx.status = 500;
    ctx.body = { success: false, error: err.message };
  }
});

module.exports = router;


