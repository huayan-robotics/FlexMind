// src/routes/ros-routes.js
const Router = require("@koa/router");
const rosBridgeService = require("../services/rosBridgeService");

const router = new Router({ prefix: "/ros" });

// 健康检查
router.get('/health', async (ctx) => {
  ctx.success({ status: 'ok', timestamp: Date.now() });
});

// 发布 String 示例：POST /ros/publish/string
router.post("/publish/string", async (ctx) => {
  const { topic, message } = ctx.request.body;
  if (!topic || typeof message !== "string") {
    ctx.status = 400;
    ctx.body = { success: false, error: "需提供 topic 和 message 字符串" };
    return;
  }
  try {
    rosBridgeService.publish(topic, { data: message });
    ctx.body = { success: true };
  } catch (e) {
    ctx.status = 500;
    ctx.body = { success: false, error: e.message };
  }
});

// 服务调用示例：POST /ros/ros1/call_service
router.post("/ros1/call_service", async (ctx) => {
  const { service, type, args } = ctx.request.body || {};

  // 若未提供 service，则不做服务调用
  if (!service) {
    ctx.success(null);
    return;
  }
  try {
    const resp = await rosBridgeService.callService(service, type, args);
    // 直接透传 rosbridge 的响应对象（例如 service_response）
    ctx.body = resp;
  } catch (e) {
    ctx.status = 500;
    ctx.fail("ROS_SERVICE_ERROR", e.message);
  }
});

// 服务调用示例：POST /ros/call_service
router.post("/call_service", async (ctx) => {
  const { service, type, args } = ctx.request.body || {};

  // 若未提供 service，则不做服务调用
  if (!service) {
    ctx.success(null);
    return;
  }
  try {
    const safeArgs = (args && typeof args === 'object') ? args : {};
    const resp = await rosBridgeService.callService(service, type, safeArgs);
    // 直接透传 rosbridge 的响应对象（例如 service_response）
    ctx.body = resp;
  } catch (e) {
    ctx.status = 500;
    ctx.fail("ROS_SERVICE_ERROR", e.message);
  }
});

/**
 * POST /ros/send_action_goal
 * body: { actionName: string, actionType: string, goal: object }
 * 向后端 rosbridge 发送 Action Goal，并通过回调反馈 via WebSocket 或 SSE
 */
router.post("/send_action_goal", async (ctx) => {
  const {
    op,
    id,
    action,
    action_type,
    args,
    feedback = true,
    fragment_size,
    compression,
  } = ctx.request.body;
  if (op !== "send_action_goal" || !action || !action_type) {
    ctx.status = 400;
    ctx.body = {
      error:
        'Invalid parameters. Expected op:"send_action_goal", action:string, action_type:string',
    };
    return;
  }
  // 构造发送 payload
  const payload = { op: "send_action_goal", action, action_type };
  if (id) payload.id = id;
  if (args) payload.args = args;
  if (feedback !== undefined) payload.feedback = feedback;
  if (fragment_size) payload.fragment_size = fragment_size;
  if (compression) payload.compression = compression;

  try {
    // 等待 rosbridge 返回 action_result 响应
    const resultPromise = new Promise((resolve, reject) => {
      const reqId = id || `req_${Date.now()}`;
      const callback = (resp) => {
        if (
          resp.op === "action_result" &&
          resp.id === reqId &&
          resp.action === action
        ) {
          resolve(resp);
        }
      };
      rosBridgeService.pending.set(reqId, callback);
      rosBridgeService._send(payload);
    });

    const resp = await resultPromise;
    ctx.body = resp;
  } catch (err) {
    ctx.status = 500;
    ctx.body = { error: err.message };
  }
});

/**
 * POST /ros/cancel_action_goal
 * body: { actionName: string, goalId: { stamp: { sec:number,nsec:number }, uuid: { [number]:number[] } } }
 * 调用 ROS2 Action 的 cancel_goal 服务
 */
router.post("/cancel_action_goal", async (ctx) => {
  const { op, id, action } = ctx.request.body;
  if (op !== "cancel_action_goal" || !id || !action) {
    ctx.status = 400;
    ctx.body = {
      error:
        'Invalid parameters. Expected { op: "cancel_action_goal", id: string, action: string }',
    };
    return;
  }

  try {
    // 直接通过 rosBridgeService._send 发送自定义 op
    const resultPromise = new Promise((resolve, reject) => {
      // 监听对应 id 的响应
      const callback = (resp) => {
        if (
          resp.op === "action_result" &&
          resp.id === id &&
          resp.action === action
        ) {
          resolve(resp);
        }
      };
      // 注册临时监听
      rosBridgeService.pending.set(id, callback);
      // 发送取消请求
      rosBridgeService._send({ op: "cancel_action_goal", id, action });
    });

    const resp = await resultPromise;
    ctx.body = resp;
  } catch (err) {
    ctx.status = 500;
    ctx.body = { error: err.message };
  }
});

module.exports = router;
