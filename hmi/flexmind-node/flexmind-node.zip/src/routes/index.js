// src/routes/index.js
const Router = require('@koa/router');
const homeController = require('../controllers/home-controller');
const userController = require('../controllers/user-controller');

const router = new Router();

// 首页
router.get('/', homeController.index);

// 健康检查
router.get('/health', async (ctx) => {
  ctx.success({ status: 'ok', timestamp: Date.now() });
});

// 用户相关路由
const userRouter = new Router({
  prefix: '/users'
});

// 列表
userRouter.get('/', userController.listUsers);
// 获取单个用户
userRouter.get('/:id', userController.getUser);
// 创建用户
userRouter.post('/', userController.createUser);

router.use(userRouter.routes(), userRouter.allowedMethods());

module.exports = router;
