// src/routes/playback-files.js
const Router = require('@koa/router');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const archiver = require('archiver');
const sendToWormhole = require('stream-wormhole');
const helper = require('../extend/helper');
const { log } = require('console');

const router = new Router({ prefix: '/playback_files' });

// 工具函数：检查目录并在必要时创建
async function ensureDir(dirPath) {
  try {
    await fsp.mkdir(dirPath, { recursive: true });
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
  }
}

// POST /playback_files/import_file
// 支持多种上传方式：form-data、二进制流、JSON批量导入
router.post('/import_file', async (ctx) => {
  try {
    const files = ctx.request.files || {};
    const body = ctx.request.body || {};
    const contentType = ctx.request.headers['content-type'] || '';

    console.log('[import_file] 请求信息:', {
      contentType,
      filesKeys: Object.keys(files),
      bodyKeys: Object.keys(body),
      headers: ctx.request.headers
    });

    const file = files.files || files.file || files.upload || files.data;
    const destinationPath = body.path;

    console.log('[import_file] 解析结果:', {
      file: file ? '存在' : '不存在',
      fileType: file ? typeof file : 'undefined',
      fileIsArray: file ? Array.isArray(file) : 'undefined',
      destinationPath
    });

    // 情况1：form-data 文件上传
    if (file) {
      console.log('[import_file] 进入 form-data 文件上传处理');
    // 处理单文件或多文件上传
    const fileList = Array.isArray(file) ? file : [file];
    const results = [];

      console.log(
        '[import_file] 文件列表:',
        fileList.map((f) => ({
        filepath: f.filepath || f.path,
        originalFilename: f.originalFilename || f.name,
        size: f.size
        }))
      );

    for (const uploaded of fileList) {
      const tempPath = uploaded.filepath || uploaded.path;
        const filename =
          uploaded.originalFilename || uploaded.name || path.basename(tempPath);

        console.log('[import_file] 处理文件:', { tempPath, filename });

      if (!tempPath || !fs.existsSync(tempPath)) {
          console.warn('[import_file] 临时文件不存在:', { tempPath, filename });
        results.push({ filename, ok: false, reason: '临时上传文件不存在' });
        continue;
      }

        console.log('[import_file] 临时文件存在，开始处理:', {
          tempPath,
          filename
        });

        // 确定目标路径
        let targetPath;
        if (destinationPath && typeof destinationPath === 'string') {
          const resolvedPath = path.isAbsolute(destinationPath)
            ? destinationPath
            : path.resolve(process.cwd(), destinationPath);

          console.log('[import_file] 指定目标路径:', {
            destinationPath,
            resolvedPath
          });

          if (path.extname(resolvedPath) === '') {
            targetPath = path.join(resolvedPath, filename);
            console.log(
              '[import_file] 目标路径是目录，添加文件名:',
              targetPath
            );
          } else {
            targetPath = resolvedPath;
            console.log('[import_file] 目标路径是文件:', targetPath);
          }
        } else {
          // 使用默认路径 - fleximind-ros1/data/bags
          const defaultDir = '/home/robot/fleximind-ros1/data/bags';
          await ensureDir(defaultDir);
          targetPath = path.join(defaultDir, filename);
          console.log('[import_file] 使用默认路径:', {
            defaultDir,
            targetPath
          });
        }

        const targetDir = path.dirname(targetPath);
        console.log('[import_file] 目标目录:', targetDir);
        await ensureDir(targetDir);
        console.log('[import_file] 目标目录已创建/确认存在');

        try {
          console.log('[import_file] 开始流式复制:', {
            from: tempPath,
            to: targetPath
          });
        // 流式复制文件
        const result = await new Promise((resolve, reject) => {
            const readStream = fs.createReadStream(tempPath, {
              highWaterMark: 1024 * 1024
            });
            const writeStream = fs.createWriteStream(targetPath, {
              highWaterMark: 1024 * 1024
            });

          let errFlag = false;

            readStream.on('error', (err) => {
              console.error('[import_file] 读取流错误:', err);
              errFlag = true;
              writeStream.destroy();
              reject(err);
            });

            writeStream.on('error', (err) => {
              console.error('[import_file] 写入流错误:', err);
            errFlag = true;
            sendToWormhole(readStream);
            writeStream.destroy();
            reject(err);
          });

          writeStream.on('finish', () => {
              console.log('[import_file] 写入完成');
            if (errFlag) return;
              resolve({ filename, path: targetPath });
          });

            console.log('[import_file] 开始管道传输');
          readStream.pipe(writeStream);
        });

          console.log('[import_file] 流式复制完成，开始验证文件');

        // 验证文件是否成功写入
          const exists = await fsp
            .access(targetPath)
            .then(() => true)
            .catch(() => false);
          const stat = exists ? await fsp.stat(targetPath) : null;

          console.log('[import_file] 文件验证结果:', {
            targetPath,
            exists,
            size: stat ? stat.size : 'N/A',
            mtime: stat ? stat.mtime : 'N/A'
          });

        results.push({
          filename: result.filename,
          path: result.path,
          ok: exists,
          reason: exists ? undefined : '目标文件校验失败'
        });
      } catch (err) {
          console.error('[import_file] 流式复制失败:', {
            from: tempPath,
            to: targetPath,
            error: err.message,
            stack: err.stack
          });
        results.push({ filename, ok: false, reason: err.message });
      }
    }

      const okCount = results.filter((r) => r.ok).length;
      console.log('[import_file] form-data 上传结果汇总:', {
        okCount,
        total: results.length,
        results
      });

    if (okCount === 0) {
      ctx.status = 500;
        ctx.body = {
          success: false,
          error: '所有文件上传失败',
          uploaded: results
        };
    } else {
      ctx.body = { success: true, uploaded: results };
    }
      return;
    }

    // 情况2：原始二进制流上传
    if (!contentType.includes('multipart/form-data')) {
      console.log('[import_file] 进入二进制流上传处理');
      const filename =
        ctx.request.headers['x-filename'] ||
                      ctx.request.headers['filename'] ||
                      'uploaded_file';

      console.log('[import_file] 二进制流文件名:', filename);

      let targetPath;
      if (destinationPath && typeof destinationPath === 'string') {
        const resolvedPath = path.isAbsolute(destinationPath)
          ? destinationPath
          : path.resolve(process.cwd(), destinationPath);

        if (path.extname(resolvedPath) === '') {
          targetPath = path.join(resolvedPath, filename);
        } else {
          targetPath = resolvedPath;
        }
      } else {
        // 使用默认路径 - fleximind-ros1/data/bags
        const defaultDir = '/home/robot/fleximind-ros1/data/bags';
        await ensureDir(defaultDir);
        targetPath = path.join(defaultDir, filename);
        console.log('[import_file] 二进制流使用默认路径:', {
          defaultDir,
          targetPath
        });
      }

      const targetDir = path.dirname(targetPath);
      await ensureDir(targetDir);

      try {
        const result = await new Promise((resolve, reject) => {
          const writeStream = fs.createWriteStream(targetPath, {
            highWaterMark: 1024 * 1024
          });

          let hasError = false;

          writeStream.on('error', (err) => {
            hasError = true;
            writeStream.destroy();
            reject(err);
          });

          writeStream.on('finish', () => {
            if (!hasError) resolve({ filename, path: targetPath });
          });

          // 直接将请求流管道到文件
          ctx.req.pipe(writeStream);
        });

        const exists = await fsp
          .access(targetPath)
          .then(() => true)
          .catch(() => false);
        console.log('[import_file] 二进制流上传结果:', {
          filename,
          path: targetPath,
          exists
        });

        if (exists) {
          ctx.body = {
            success: true,
            uploaded: [
              { filename: result.filename, path: result.path, ok: true }
            ]
          };
        } else {
          ctx.status = 500;
          ctx.body = {
            success: false,
            error: '文件上传失败',
            uploaded: [
              {
                filename: result.filename,
                path: result.path,
                ok: false,
                reason: '目标文件校验失败'
              }
            ]
          };
        }
        return;
      } catch (err) {
        console.error('[import_file] 二进制流上传失败:', {
          error: err.message
        });
        ctx.status = 500;
        ctx.body = { success: false, error: err.message };
        return;
      }
    }

    // 没有文件上传
    console.log('[import_file] 没有检测到文件上传');
    ctx.status = 400;
    ctx.body = { success: false, error: '缺少文件字段 files' };
  } catch (err) {
    console.error('[import_file] 处理异常:', {
      error: err.message,
      stack: err.stack
    });
    ctx.status = 500;
    ctx.body = { success: false, error: err.message };
  }
});

// POST /playback_files/export_file
// 使用系统 zip 命令压缩文件后导出
router.post('/export_file', async (ctx) => {
  console.log('[export_file] ===== 开始处理导出请求（使用 zip 压缩） =====');
  console.log('[export_file] 请求时间:', new Date().toISOString());

  ctx.req.setTimeout(10 * 60 * 1000);
  ctx.res.setTimeout(10 * 60 * 1000);

  const zipPath = path.join('/tmp', `exported_${Date.now()}.zip`);

  try {
    const body = ctx.request.body || {};
    const { export_path } = body;
    console.log('[export_file] 收到导出请求:', { export_path });

    if (!export_path) {
      ctx.status = 400;
      ctx.body = { success: false, error: '缺少 export_path 参数' };
      return;
    }

    // 处理路径数组或单个路径
    const paths = Array.isArray(export_path) ? export_path : [export_path];
    console.log('[export_file] 处理路径列表:', paths);

    // 验证所有路径
    const validPaths = [];
    for (const pathItem of paths) {
      if (!pathItem || typeof pathItem !== 'string') {
        console.warn('[export_file] 跳过无效路径:', pathItem);
        continue;
      }

      const resolvedPath = path.isAbsolute(pathItem)
        ? pathItem
        : path.resolve(process.cwd(), pathItem);

      console.log('[export_file] 检查路径:', { original: pathItem, resolved: resolvedPath });

      try {
        const stats = fs.statSync(resolvedPath);

        if (stats.isFile()) {
          console.log('[export_file] 路径是文件:', { path: resolvedPath, size: stats.size });
          validPaths.push({ path: resolvedPath, isFile: true });
        } else if (stats.isDirectory()) {
          console.log('[export_file] 路径是目录:', { path: resolvedPath });
          validPaths.push({ path: resolvedPath, isFile: false });
        }
      } catch (err) {
        console.error('[export_file] 路径不存在或无法访问:', { path: resolvedPath, error: err.message });
      }
    }

    if (validPaths.length === 0) {
      ctx.status = 404;
      ctx.body = { success: false, error: '所有导出路径都不存在或无法访问' };
      return;
    }

    console.log('[export_file] 有效路径数量:', validPaths.length);

    // 删除已存在的临时 zip 文件
    if (fs.existsSync(zipPath)) {
      fs.unlinkSync(zipPath);
      console.log('[export_file] 删除旧的临时文件:', zipPath);
    }

    // 使用系统 zip 命令压缩
    console.log('[export_file] 开始使用系统 zip 命令压缩...');

    let zipCommand;
    if (validPaths.length === 1 && validPaths[0].isFile) {
      // 单个文件：使用 -j 参数（不保留目录结构）
      zipCommand = `zip -j "${zipPath}" "${validPaths[0].path}"`;
      console.log('[export_file] 压缩单个文件命令:', zipCommand);
    } else {
      // 多个文件或目录：使用 -r 参数（递归压缩）
      const pathsString = validPaths.map(v => `"${v.path}"`).join(' ');
      zipCommand = `zip -r "${zipPath}" ${pathsString}`;
      console.log('[export_file] 压缩多个路径命令:', zipCommand);
    }

    try {
      console.log('[export_file] 执行 zip 命令...');
      const { execSync } = require('child_process');
      execSync(zipCommand, { stdio: 'pipe' });
      console.log('[export_file] zip 命令执行完成');
    } catch (zipError) {
      console.error('[export_file] zip 命令执行失败:', {
        error: zipError.message,
        stderr: zipError.stderr?.toString(),
        stdout: zipError.stdout?.toString()
      });
      ctx.status = 500;
      ctx.body = { success: false, error: '文件压缩失败: ' + zipError.message };
      return;
    }

    // 检查压缩文件是否创建成功
    if (!fs.existsSync(zipPath)) {
      console.error('[export_file] zip 文件未创建:', zipPath);
      ctx.status = 500;
      ctx.body = { success: false, error: '压缩文件创建失败' };
      return;
    }

    const zipStats = fs.statSync(zipPath);
    console.log('[export_file] zip 文件创建成功:', {
      path: zipPath,
      size: zipStats.size
    });

    // 设置响应头
    const zipName = 'exported_files.zip';
    ctx.set('Content-Type', 'application/zip');
    ctx.set('Content-Disposition', `attachment; filename="${zipName}"; filename*=UTF-8''${encodeURIComponent(zipName)}`);
    ctx.set('Content-Length', zipStats.size);
    ctx.set('Cache-Control', 'no-cache');
    ctx.set('Content-Encoding', 'identity'); // 明确指定不压缩
    ctx.set('X-Content-Type-Options', 'nosniff');

    console.log('[export_file] 响应头已设置:', {
      'Content-Type': 'application/zip',
      'Content-Length': zipStats.size,
      'Content-Encoding': 'identity'
    });

    // 使用 ctx.respond = false 手动控制响应流
    ctx.status = 200;
    ctx.respond = false;

    // 创建 zip 文件流
    const zipStream = fs.createReadStream(zipPath, { highWaterMark: 1024 * 1024 });

    // 监控传输进度
    let transferred = 0;
    zipStream.on('data', (chunk) => {
      transferred += chunk.length;
      if (transferred % (5 * 1024 * 1024) === 0) { // 每5MB打印一次
        console.log('[export_file] ZIP 传输进度:', {
          transferred,
          total: zipStats.size,
          percent: Math.round((transferred / zipStats.size) * 100)
        });
      }
    });

    zipStream.on('end', () => {
      console.log('[export_file] ZIP 文件流传输完成:', {
        transferred,
        expectedSize: zipStats.size,
        complete: transferred === zipStats.size
      });
    });

    zipStream.on('error', (err) => {
      console.error('[export_file] ZIP 文件流错误:', err);
    });

    // 监听响应流完成
    ctx.res.on('finish', () => {
      console.log('[export_file] ✓ 响应流已完成');
    });

    ctx.res.on('close', () => {
      console.log('[export_file] ✓ 响应流已关闭');
    });

    ctx.res.on('error', (err) => {
      console.error('[export_file] ✗ 响应流错误:', err);
    });

    // 将 zip 文件流管道到响应
    console.log('[export_file] 开始传输 ZIP 文件...');
    zipStream.pipe(ctx.res);

    // 等待传输完成
    await new Promise((resolve, reject) => {
      zipStream.once('end', () => {
        console.log('[export_file] ZIP 流结束');
        resolve();
      });
      zipStream.once('error', reject);
      ctx.res.once('finish', () => {
        console.log('[export_file] 响应流完成');
        resolve();
      });
      ctx.res.once('close', () => {
        console.log('[export_file] 响应流关闭');
        resolve();
      });
      ctx.res.once('error', reject);
    });

    // 清理临时文件
    setTimeout(() => {
      if (fs.existsSync(zipPath)) {
        fs.unlinkSync(zipPath);
        console.log('[export_file] 清理临时文件:', zipPath);
      }
    }, 10000);

    console.log('[export_file] ✓ ZIP 导出完成');
    return;

  } catch (err) {
    console.error('[export_file] ===== 导出异常 =====');
    console.error('[export_file] 异常时间:', new Date().toISOString());
    console.error('[export_file] 异常详情:', {
      message: err.message,
      name: err.name,
      code: err.code,
      stack: err.stack
    });

    // 清理临时文件
    if (fs.existsSync(zipPath)) {
      try {
        fs.unlinkSync(zipPath);
        console.log('[export_file] 异常处理：清理临时文件');
      } catch (e) {
        console.error('[export_file] 清理临时文件失败:', e);
      }
    }

    console.log('[export_file] 设置错误响应...');
      ctx.status = 500;
      ctx.body = { success: false, error: err.message || String(err) };
    console.log('[export_file] ===== 导出异常处理完成 =====');
  }
});

module.exports = router;
