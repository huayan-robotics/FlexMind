// src/services/userService.js

// 内存存储示例，仅作演示
let users = [
  { id: '1', name: 'Alice', email: 'alice@example.com' },
  { id: '2', name: 'Bob', email: 'bob@example.com' }
];

// 生成随机 ID（示例，生产请用 UUID 等）
function generateId() {
  return Date.now().toString();
}

exports.findById = async (id) => {
  // 模拟异步
  return users.find(u => u.id === id) || null;
};

exports.list = async ({ page, limit }) => {
  const start = (page - 1) * limit;
  const end = start + limit;
  const items = users.slice(start, end);
  return {
    total: users.length,
    page,
    limit,
    items
  };
};

exports.create = async ({ name, email }) => {
  const id = generateId();
  const newUser = { id, name, email };
  users.push(newUser);
  return newUser;
};
