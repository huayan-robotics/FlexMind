// src/services/rosBridgeService.js
const WebSocket = require('ws');
const EventEmitter = require('events');

class RosBridgeService extends EventEmitter {
  constructor() {
    super();
    this.ws = null;
    this.requestId = 0;
    this.pending = new Map(); // id -> callback
    this.subscribedTopics = new Map(); // 记录已订阅的 topic: topicName -> { type, callback }
    this.url = null; // 保存连接 URL 用于重连
    this.isReconnecting = false; // 重连状态标志
    this.reconnectTimer = null; // 重连定时器
    this.connectTimeoutHandle = null; // 连接超时定时器
    this.baseRetryDelayMs = 1000; // 初始退避
    this.maxRetryDelayMs = 30000; // 最大退避
    this._retryDelay = this.baseRetryDelayMs;
  }

  /**
   * 连接到 rosbridge WebSocket
   * @param {string} url rosbridge WebSocket URL, e.g. 'ws://localhost:9090'
   */
  connect(url) {
    if (!url) {
      console.error('[RosBridgeService] URL is required');
      return;
    }

    // 保存 URL 用于重连
    this.url = url;

    // 如果正在重连，取消之前的重连定时器
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    // 如果已经有连接，先清理
    if (this.ws) {
      try {
        // 移除所有事件监听器，避免重复绑定
        this.ws.removeAllListeners();
        if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CLOSING) {
          this.ws.close();
        } else {
          this.ws.terminate();
        }
      } catch (err) {
        console.warn('[RosBridgeService] Error closing existing connection:', err.message);
      }
      this.ws = null;
    }

    // 如果正在重连，避免重复连接
    if (this.isReconnecting) {
      console.log('[RosBridgeService] Already reconnecting, skipping...');
      return;
    }

    const connectTimeoutMs = 5000;
    console.log(`[RosBridgeService] Connecting to ${url}...`);
    
    try {
      this.ws = new WebSocket(url);
    } catch (err) {
      console.error('[RosBridgeService] Failed to create WebSocket:', err.message);
      this._scheduleReconnect();
      return;
    }

    // 连接超时保护
    this.connectTimeoutHandle = setTimeout(() => {
      try {
        if (this.ws && this.ws.readyState !== WebSocket.OPEN) {
          console.warn('[RosBridgeService] Connection timeout');
          this.ws.terminate();
        }
      } catch (err) {
        console.warn('[RosBridgeService] Error terminating timeout connection:', err.message);
      }
    }, connectTimeoutMs);

    this.ws.on('open', () => {
      if (this.connectTimeoutHandle) {
        clearTimeout(this.connectTimeoutHandle);
        this.connectTimeoutHandle = null;
      }
      // 重置退避和重连状态
      this._retryDelay = this.baseRetryDelayMs;
      this.isReconnecting = false;
      console.log(`[RosBridgeService] Connected to ${url}`);
      this.emit('connected');
      
      // 重新订阅之前订阅的主题
      this._resubscribeTopics();
    });

    this.ws.on('message', (data) => {
      let msg;
      try {
        msg = JSON.parse(data);
      } catch (e) {
        console.warn('[RosBridgeService] Received non-JSON message:', data);
        return;
      }
      // 如果是服务调用或其他带 id 的响应
      if (msg.id && this.pending.has(msg.id)) {
        const cb = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        cb(msg);
      } else {
        // 如果是订阅发布消息
        // rosbridge 发布消息格式：{ op: 'publish', topic: '/chatter', msg: {...} }
        if (msg.op === 'publish' && msg.topic) {
          // 触发事件，携带 topic 和消息体
          this.emit('topic:' + msg.topic, msg.msg);
        }
      }
    });

    this.ws.on('error', (err) => {
      console.error('[RosBridgeService] WebSocket error:', err.message);
      this.emit('error', err);
    });

    this.ws.on('close', (code, reason) => {
      if (this.connectTimeoutHandle) {
        clearTimeout(this.connectTimeoutHandle);
        this.connectTimeoutHandle = null;
      }
      console.log(`[RosBridgeService] WebSocket closed: code=${code}, reason=${reason || 'no reason'}`);
      this.ws = null;
      this.emit('disconnected', { code, reason });
      
      // 只有在非手动关闭的情况下才重连
      if (code !== 1000) { // 1000 是正常关闭
        this._scheduleReconnect();
      }
    });
  }

  /**
   * 安排重连
   * @private
   */
  _scheduleReconnect() {
    if (this.isReconnecting) {
      return;
    }
    
    if (!this.url) {
      console.error('[RosBridgeService] Cannot reconnect: URL not set');
      return;
    }

    this.isReconnecting = true;
    const delay = this._retryDelay;
    this._retryDelay = Math.min(this._retryDelay * 2, this.maxRetryDelayMs);
    
    console.log(`[RosBridgeService] Scheduling reconnect in ${delay}ms (next retry delay: ${this._retryDelay}ms)`);
    
    this.reconnectTimer = setTimeout(() => {
      this.isReconnecting = false;
      this.reconnectTimer = null;
      this.connect(this.url);
    }, delay);
  }

  /**
   * 重新订阅之前订阅的主题
   * @private
   */
  _resubscribeTopics() {
    if (this.subscribedTopics.size === 0) {
      return;
    }
    
    console.log(`[RosBridgeService] Resubscribing to ${this.subscribedTopics.size} topics...`);
    for (const [topicName, info] of this.subscribedTopics.entries()) {
      try {
        this._send({
          op: 'subscribe',
          topic: topicName,
          type: info.type
        });
        // 注意：回调已经在 subscribe 方法中通过 this.on() 注册，不需要重新注册
        // EventEmitter 的监听器绑定在 RosBridgeService 实例上，不会因为 WebSocket 重连而丢失
        console.log(`[RosBridgeService] Resubscribed to ${topicName} (${info.type})`);
      } catch (err) {
        console.error(`[RosBridgeService] Failed to resubscribe to ${topicName}:`, err.message);
      }
    }
  }

  /**
   * 发送消息到 rosbridge，并可注册回调
   * @param {object} obj 要发送的对象，将被 JSON.stringify
   * @param {(response: object) => void} [callback] 可选，用于服务调用等
   */
  _send(obj, callback) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.error('[RosBridgeService] WebSocket not open. Cannot send:', obj);
      return;
    }
    const id = (++this.requestId).toString();
    obj.id = id;
    if (callback) {
      this.pending.set(id, callback);
    }
    this.ws.send(JSON.stringify(obj));
  }

  /**
   * 订阅 ROS2 主题
   * @param {string} topicName 主题名，如 '/chatter'
   * @param {string} type ROS 消息类型，如 'std_msgs/String'（rosbridge 格式，不带 'msg' 关键字）
   * @param {(msg: object) => void} callback 收到消息时回调
   */
  subscribe(topicName, type, callback) {
    // rosbridge 要求 type 格式如 'std_msgs/String'
    // 如果用户传入 'std_msgs/msg/String'，需要转换为 'std_msgs/String'
    let rosbridgeType = type;
    if (type.includes('/msg/')) {
      // 从 'std_msgs/msg/String  ' -> 'std_msgs/String'
      rosbridgeType = type.replace('/msg/', '/');
    }
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.error('[RosBridgeService] WebSocket not open. Cannot subscribe:', topicName);
      // 即使未连接，也保存订阅信息，以便重连后自动订阅
      this.subscribedTopics.set(topicName, { type: rosbridgeType, callback });
      this.on('topic:' + topicName, callback);
      return;
    }
    if (this.subscribedTopics.has(topicName)) {
      console.warn(`[RosBridgeService] Already subscribed to ${topicName}`);
    } else {
      this._send({
        op: 'subscribe',
        topic: topicName,
        type: rosbridgeType
      });
      console.log(`[RosBridgeService] Subscribing to ${topicName} (${rosbridgeType})`);
    }
    // 保存订阅信息（包括回调），用于重连后重新订阅
    this.subscribedTopics.set(topicName, { type: rosbridgeType, callback });
    // 注册本地回调：每次收到该 topic 消息时，ws.on('message') 解析后会 emit 'topic:<topicName>'
    this.on('topic:' + topicName, callback);
  }

  /**
   * 取消订阅主题
   * @param {string} topicName
   * @param {string} type ROS 消息类型，如 'std_msgs/String' 或 'std_msgs/msg/String'
   */
  unsubscribe(topicName, type) {
    if (!this.subscribedTopics.has(topicName)) {
      console.warn(`[RosBridgeService] Not subscribed to ${topicName}`);
      return;
    }
    
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      // rosbridge unsubscribe
      this._send({
        op: 'unsubscribe',
        topic: topicName
      });
    } else {
      console.warn('[RosBridgeService] WebSocket not open. Removing subscription from cache only:', topicName);
    }
    
    this.subscribedTopics.delete(topicName);
    // 移除所有注册在 'topic:<topicName>' 事件的回调
    this.removeAllListeners('topic:' + topicName);
    console.log(`[RosBridgeService] Unsubscribed from ${topicName}`);
  }

  /**
   * 发布 ROS2 消息到主题
   * @param {string} topicName
   * @param {object} msgObj 消息对象，例如 { data: 'hello' } 对于 std_msgs/String
   */
  publish(topicName, msgObj) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.error('[RosBridgeService] WebSocket not open. Cannot publish:', topicName);
      return;
    }
    this._send({
      op: 'publish',
      topic: topicName,
      msg: msgObj
    });
    console.log(`[RosBridgeService] Publishing to ${topicName}:`, msgObj);
  }

  /**
   * 调用 ROS1 服务
   * @param {string} serviceName 服务名，如 '/add_two_ints'
   * @returns {Promise<object>} 服务响应对象
   */
  callRos1Service(serviceName) {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        return reject(new Error('WebSocket not open'));
      }
      // rosbridge call_service 格式：{ op: 'call_service', service: serviceName, type: type, args: args }
      this._send({
        op: 'call_service',
        service: serviceName,
      }, (resp) => {
        console.log(resp);
        // resp 可能包含 { result: true/false, values: {...} }
        if (resp.result === false) {
          reject(new Error(`Service call failed: ${JSON.stringify(resp)}`));
        } else {
          // rosbridge response 中，响应字段可能在 resp.values 或直接在 resp
          resolve(resp.values !== undefined ? resp.values : resp);
        }
      });
    });
  }

  /**
   * 调用 ROS2 服务
   * @param {string} serviceName 服务名，如 '/add_two_ints'
   * @param {string} type ROS 服务类型，如 'example_interfaces/AddTwoInts'
   * @param {object} args 请求对象，例如 { a: 1, b: 2 }
   * @returns {Promise<object>} 服务响应对象
   */
  callService(serviceName, type, args) {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        return reject(new Error('WebSocket not open'));
      }
      // rosbridge call_service 格式：{ op: 'call_service', service: serviceName, type: type, args: args }
      this._send({
        op: 'call_service',
        service: serviceName,
        type: type,
        args: args
      }, (resp) => {
        console.log(resp);
        // resp 可能包含 { result: true/false, values: {...} }
        if (resp.result === false) {
          reject(new Error(`Service call failed: ${JSON.stringify(resp)}`));
        } else {
          // rosbridge response 中，响应字段可能在 resp.values 或直接在 resp
          resolve(resp.values !== undefined ? resp.values : resp);
        }
      });
    });
  }

  /**
   * 发送动作目标
   * @param {string} actionName 动作名，如 '/navigate_to_pose'
   * @param {string} actionType 动作类型，如 'nav2_msgs/action/NavigateToPose'
   * @param {object} goal 动作目标对象
   * @param {(feedback: object) => void} feedbackCb 反馈回调函数
   * @returns {Promise<object>} 动作结果对象
   */
  sendActionGoal(actionName, actionType, goal, feedbackCb) {
    const sendGoalService = `${actionName}/_action/send_goal`;
    const feedbackTopic = `${actionName}/_action/send_goal/feedback`;
    const resultTopic = `${actionName}/_action/send_goal/result`;

    const sendGoalType = `${actionType}_SendGoal`;
    const feedbackType = `${actionType}_Feedback`;
    const resultType = `${actionType}_Result`;

    this.subscribe(feedbackTopic, feedbackType, feedbackCb);
    this.subscribe(resultTopic, resultType);

    return new Promise((resolve, reject) => {
      this.callService(sendGoalService, sendGoalType, { goal }).then((resp) => {
        const onResult = (msg) => {
          resolve(msg);
          this.unsubscribe(feedbackTopic);
          this.unsubscribe(resultTopic);
          this.removeListener('topic:' + resultTopic, onResult);
        };
        this.on('topic:' + resultTopic, onResult);
      }).catch(reject);
    });
  }
}

module.exports = new RosBridgeService();
