// src/index.js

require("dotenv").config();
const http = require("http");
const { Server: SocketIOServer } = require("socket.io");

const config = require("../config/default");
const rosBridgeService = require("./services/rosBridgeService");
const app = require("./app");

async function main() {
  // 1. 连接到 rosbridge WebSocket
  const rosbridgeUrl = config.rosbridgeWsUrl;
  rosBridgeService.connect(rosbridgeUrl);

  // 可监听连接事件，若想在 rosbridge 连接后再执行某些操作：
  rosBridgeService.on("connected", () => {
    console.log(`[Main] rosbridge connected at ${rosbridgeUrl}`);
    // 如果需要在启动时预先订阅某些主题，可在这里调用 rosBridgeService.subscribe(...)
  });
  rosBridgeService.on("error", (err) => {
    // console.error("[Main] rosBridgeService error:", err);
  });
  rosBridgeService.on("disconnected", ({ code, reason }) => {
    console.warn(`[Main] rosBridgeService disconnected: code=${code}, reason=${reason || 'no reason'}`);
    // 注意：rosBridgeService 内部已经处理了自动重连，这里不需要再次调用 connect
    // 如果需要额外的重连逻辑，可以在这里添加
  });

  // 2. 创建 HTTP server，让 Koa 处理
  const koaCallback = app.callback();
  const server = http.createServer(koaCallback);

  // 3. 初始化 Socket.IO，绑定到 HTTP server
  const io = new SocketIOServer(server, {
    cors: {
      origin: config.socketioCorsOrigin,
      methods: ["GET", "POST"],
    },
  });

  // 4. 管理订阅引用计数：Map topic -> { count, type }
  const topicRefCount = new Map();

  io.on("connection", (socket) => {
    console.log(`Socket.IO client connected: ${socket.id}`);

    // 客户端请求订阅 ROS2 主题
    socket.on("subscribe_topic", ({ topic, msgType }) => {
      if (!topic || !msgType) {
        socket.emit("subscribed", {
          topic,
          success: false,
          error: "需提供 topic 和 msgType",
        });
        return;
      }
      const key = topic;
      const entry = topicRefCount.get(key);
      if (!entry) {
        // 首次订阅该 topic
        try {
          rosBridgeService.subscribe(topic, msgType, (msg) => {
            // msg 是 ROS 消息对象，直接转发给该房间内所有客户端
            io.to(topic).emit("ros_message", { topic, msg });
          });
          topicRefCount.set(key, { count: 1, msgType });
          console.log(`[Main] First subscription for ${topic} via rosbridge`);
        } catch (err) {
          console.error(`[Main] subscribe_topic error for ${topic}:`, err);
          socket.emit("subscribed", {
            topic,
            success: false,
            error: err.message,
          });
          return;
        }
      } else {
        // 已有订阅，增加计数；检查 msgType 是否一致
        if (entry.msgType !== msgType) {
          console.warn(
            `[Main] subscribe_topic same topic ${topic} but different msgType: existing=${entry.msgType}, new=${msgType}`
          );
          socket.emit("subscribed", {
            topic,
            success: false,
            error: `已订阅 ${topic}，msgType 不同`,
          });
          return;
        }
        entry.count += 1;
        topicRefCount.set(key, entry);
        console.log(
          `[Main] Increment subscription count for ${topic}: ${entry.count}`
        );
      }
      // 把 socket 加入房间
      socket.join(topic);
      socket.emit("subscribed", { topic, success: true });
    });

    // 客户端取消订阅
    socket.on("unsubscribe_topic", ({ topic, msgType }) => {
      if (!topic || !msgType) {
        socket.emit("unsubscribed", {
          topic,
          success: false,
          error: "需提供 topic 和 msgType",
        });
        return;
      }
      const key = topic;
      const entry = topicRefCount.get(key);
      if (!entry) {
        socket.emit("unsubscribed", {
          topic,
          success: false,
          error: "未订阅该 topic",
        });
        return;
      }
      if (entry.msgType !== msgType) {
        socket.emit("unsubscribed", {
          topic,
          success: false,
          error: "msgType 不匹配",
        });
        return;
      }
      // 将 socket 从房间移除
      socket.leave(topic);
      entry.count -= 1;
      console.log(
        `[Main] Decrement subscription count for ${topic}: ${entry.count}`
      );
      if (entry.count <= 0) {
        // 最后一个客户端离开，取消订阅
        rosBridgeService.unsubscribe(topic, msgType);
        topicRefCount.delete(key);
        console.log(
          `[Main] Unsubscribed ROS2 topic ${topic} after last client left`
        );
      } else {
        topicRefCount.set(key, entry);
      }
      socket.emit("unsubscribed", { topic, success: true });
    });

    // 客户端发布 ROS2 消息
    socket.on("publish_topic", ({ topic, msgType, data }) => {
      if (!topic || !msgType || data == null) {
        socket.emit("published", {
          topic,
          success: false,
          error: "需提供 topic, msgType, data",
        });
        return;
      }
      try {
        // data: 前端传来的消息对象，例如 { data: 'hello' } 对于 std_msgs/msg/String
        rosBridgeService.publish(topic, data);
        socket.emit("published", { topic, success: true });
      } catch (err) {
        console.error(`[Main] publish_topic error for ${topic}:`, err);
        socket.emit("published", { topic, success: false, error: err.message });
      }
    });

    // 处理断开：遍历 socket.rooms，减少订阅计数
    socket.on("disconnect", () => {
      console.log(`Socket.IO client disconnected: ${socket.id}`);
      const rooms = Array.from(socket.rooms).filter((r) => r !== socket.id);
      rooms.forEach((topic) => {
        const entry = topicRefCount.get(topic);
        if (entry) {
          entry.count -= 1;
          console.log(
            `[Main] After disconnect, decremented count for ${topic}: ${entry.count}`
          );
          if (entry.count <= 0) {
            rosBridgeService.unsubscribe(topic, entry.msgType);
            topicRefCount.delete(topic);
            console.log(
              `[Main] Unsubscribed ROS2 topic ${topic} after last client disconnected`
            );
          } else {
            topicRefCount.set(topic, entry);
          }
        }
      });
    });
  });

  // 5. 启动 HTTP + Socket.IO server
  server.listen(config.port, "0.0.0.0", () => {
    console.log(
      `HTTP & Socket.IO server listening on http://localhost:${config.port}`
    );
    console.log(`rosbridge WebSocket URL: ${config.rosbridgeWsUrl}`);
  });

  // 6. 优雅关闭（可视需求添加）
  const shutdown = () => {
    console.log("Shutting down server...");
    server.close(() => {
      console.log("HTTP server closed.");
      // 关闭 rosBridgeService.ws
      if (rosBridgeService.ws) {
        rosBridgeService.ws.close();
      }
      process.exit(0);
    });
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}

main().catch((err) => {
  console.error("Startup error:", err);
  process.exit(1);
});
