// src/middleware/logger.js

module.exports = async (ctx, next) => {
  const start = Date.now();
  try {
    // 执行下游中间件或路由处理
    await next();
  } finally {
    // 计算耗时
    const ms = Date.now() - start;
    // 构造日志信息
    const parts = [
      ctx.method,                // 请求方法
      ctx.url,                   // 请求 URL (包含 query)
      `Status: ${ctx.status}`,   // 响应状态码
      `Time: ${ms}ms`            // 耗时
    ];
    // 如果想加上客户端 IP，可以：
    // parts.push(`IP: ${ctx.ip}`);
    console.log(parts.join(' | '));
  }
};