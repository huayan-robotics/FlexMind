// src/middleware/error-handler.js

module.exports = async (ctx, next) => {
  try {
    await next();

    // 如果 downstream 没设置 body，且 status 还是默认 404，则返回统一 404 格式
    if (ctx.status === 404 && !ctx.body) {
      ctx.status = 404;
      ctx.body = {
        success: false,
        data: null,
        error: {
          code: 'NOT_FOUND',
          message: '资源未找到'
        }
      };
    }
  } catch (err) {
    // 日志中已由 logger 中间件打印，或者在此打印
    console.error('Unhandled Error:', err);

    ctx.status = err.status || 500;
    ctx.body = {
      success: false,
      data: null,
      error: {
        code: err.code || 'INTERNAL_SERVER_ERROR',
        message: err.message || '内部服务器错误'
      }
    };
    // 如果是开发环境，可返回 stack
    if (process.env.NODE_ENV !== 'production') {
      ctx.body.error.stack = err.stack;
    }
  }
};
