'use strict'; // 使用严格模式

const fs = require('fs');
const Stream = require('node-rtsp-stream-jsmpeg');
const callfile = require('child_process');
let stream = null;
const hisRtsp = 'rtsp://127.0.0.1:8554/live';
const portNumber = 9999;
const os = require('os');

module.exports = {
  getOperationSystem() {
    const arch = os.arch();
    const platform = os.platform();
    let pathUrl = '';
    if (platform === 'linux' && arch === 'x64') {
      // 虚拟机
      pathUrl = '/home/robot';
      // 2版本真机
      // pathUrl = '/home/RobotOS/vps';
    } else if (platform === 'linux' && arch === 'arm64') {
      // 1版本真机
      pathUrl = '/home/robot';
    }
    return pathUrl;
  },
  getStream(rtsp) {
    const rstpUrl = rtsp ? rtsp : hisRtsp;
    // 如果流不为空，则先清空后重新加载
    if (stream != null) {
      stream.stop();
      stream = null;
      const options = {
        name: 'streamNameHis' + Date.parse(new Date()),
        url: rstpUrl,
        wsPort: portNumber,
      };

      stream = new Stream(options);
      stream.start();
    } else {
      callfile.exec('sh stopHis.sh', null, function(err, stdout, stderr) {
        setTimeout(() => {
          const options = {
            name: 'streamNameHis' + Date.parse(new Date()),
            url: rstpUrl,
            wsPort: portNumber,
          };
          stream = new Stream(options);
          stream.start();
        }, 100);
      });
    }
  },
  closeStream() {
    // 关闭流
    stream.stop();
  },
  useZip(srcPath, zipPath) {
    if (fs.existsSync(zipPath)) {
      fs.unlinkSync(zipPath);
    }

    const param = {
      srcPath,
      zipPath,
      password: '12345',
    };

    // 绝对路径
    callfile.execSync(`zip  -j -P${param.password} ${param.zipPath}  ${param.srcPath} `);
    const readStream = fs.createReadStream(`${param.zipPath}`, { highWaterMark: 4096 * 4096 });

    return readStream;

  },
  allZip(srcPath, zipPath) {
    if (fs.existsSync(zipPath)) {
      fs.unlinkSync(zipPath);
    }

    const param = {
      srcPath,
      zipPath,
    };

    // 绝对路径
    callfile.execSync(`zip  -r ${param.zipPath}  ${param.srcPath} `);
    const readStream = fs.createReadStream(`${param.zipPath}`, { highWaterMark: 4096 * 4096 });

    return readStream;
  },
  exportFile(path, zipPath) {
    if (fs.existsSync(zipPath)) {
      fs.unlinkSync(zipPath);
    }
    callfile.execSync(`zip  -j  ${zipPath}  ${path} `);
    const readStream = fs.createReadStream(`${zipPath}`, { highWaterMark: 4096 * 4096 });
    return readStream;
  },
  getSteam(zipPath) {
    const readStream = fs.createReadStream(`${zipPath}`, { highWaterMark: 4096 * 4096 });
    return readStream;
  },
  execute(command) {
    const exec = callfile.exec;
    return new Promise(function(resolve, reject) {
      exec(command, function(error, stdout, stderr) {
        if (error) {
          reject(error);
        } else {
          stderr ? reject(stderr) : resolve(stdout.trim());
        }
      });
    });
  },
  parseReqBody: data => {
    let str = JSON.stringify(data).replace(/\\/g, '');
    str = str.substring(2, str.length);
    return str;
  },
};
