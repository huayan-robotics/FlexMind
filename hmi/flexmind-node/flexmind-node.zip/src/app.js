// src/app.js
const Koa = require('koa');
const { koaBody } = require('koa-body');
const cors = require('@koa/cors');
const helmet = require('koa-helmet');
const compress = require('koa-compress');
const serve = require('koa-static');
const path = require('path');
const os = require('os');

const config = require('../config/default');
const errorHandler = require('./middleware/error-handler');
const logger = require('./middleware/logger');
const responseHelper = require('./utils/responseHelper');
const router = require('./routes');
const rosHttpRouter = require('./routes/ros-routes');
const playbackFilesRouter = require('./routes/playback-files');
const compatRouter = require('./routes/compat');

const app = new Koa();

// 全局错误处理：最先使用
app.use(errorHandler);

// 日志
app.use(logger);

// 安全相关 HTTP 头
app.use(helmet());

// CORS
app.use(cors({
  origin: config.corsOrigin,
  exposeHeaders: ['Content-Disposition'],
  credentials: true,
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
}));

// 解析请求体（JSON、表单、multipart）
app.use(koaBody({
  multipart: true,
  urlencoded: true,
  json: true,
  text: false,
  formidable: {
    uploadDir: os.tmpdir(),
    keepExtensions: true
  },
  parsedMethods: ['POST', 'PUT', 'PATCH', 'DELETE']
}));

// 统一响应格式辅助
app.use(responseHelper());

// 静态文件托管：public 目录
app.use(serve(path.join(__dirname, '../public')));

// 压缩响应（排除已压缩的文件类型）
// 临时禁用压缩以测试文件传输问题
// app.use(compress({
//   filter: (content_type) => {
//     // 不压缩 ZIP、图片、视频等已压缩的文件
//     return !/application\/(zip|x-zip|x-zip-compressed|octet-stream)|image\/|video\/|audio\//i.test(content_type);
//   },
//   threshold: 2048, // 只压缩大于 2KB 的响应
// }));

// 挂载路由
app.use(router.routes());
app.use(router.allowedMethods());

// 挂载 ROS 路由
app.use(rosHttpRouter.routes());
app.use(rosHttpRouter.allowedMethods());

// 挂载回放文件相关路由
app.use(playbackFilesRouter.routes());
app.use(playbackFilesRouter.allowedMethods());

// 挂载兼容性路由
app.use(compatRouter.routes());
app.use(compatRouter.allowedMethods());

module.exports = app;
